console.log('assignment 5.1');
console.log(process.argv);

//const command = process.argv[2];

//console.log(command)


// if(command == 'add'){
//     console.log('do add .............'+process.argv[2]);
// }else if(command == 'remove'){
//     console.log('remove  ..............'+process.argv[2])
// }
//const argv = require('yargs').argv

// // help 

const argv= require('yargs').argv;

if (argv.add){
    console.log('tile .............'+argv.title);
    console.log('body.............'+argv.body);
    console.log('author.............'+argv.author);
    console.log('email.............'+argv.email);
}

var fs = require('fs');

if (argv.add){
const book = {
    title: argv.title,
    body: argv.body,
    author: argv.author,
    email: argv.email
    }

 // Covert JavaScript object into JSON string
 const bookJSON = JSON.stringify(book)
 console.log(bookJSON)
 fs.appendFile('note.js', bookJSON, function (err) {
    if (err) throw err;
    console.log('New file acme.js is either created or if exists then updated');
  });

}

else
if(argv.read){
    fs.readFile("note.js", function(err, buf) {
        console.log(buf.toString());
        // Covert JSON string into object
    // const noteObject = JSON.parse(buf)
   
    // console.log('tile .............'+noteObject.title);
    // console.log('body.............'+noteObject.body);
    // console.log('author.............'+noteObject.author);
    // console.log('email.............'+noteObject.email);

});
} 





// yargs.command({
//     command: 'add',
//     describe: 'Add a new note',
//     builder: {
//         title: {
//             describe: 'Note title',
//             demandOption: true,
//             type: 'string'
//         },
//         body: {
//             describe: 'Note body',
//             demandOption: true,
//             type: 'string'
//         }
//     },
//     handler: function(argv) {
//         console.log('Title: ' + argv.title)
//         console.log('Body: ' + argv.body)
//     }
// })

